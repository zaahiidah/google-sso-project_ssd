require('dotenv').config();

const express = require('express');
const session = require('express-session');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;

const app = express();

/* ================= MIDDLEWARE ================= */

// Parse POST requests
app.use(express.urlencoded({ extended: true }));

// Disable view caching (helps with logout + back button)
app.set('view cache', false);

// Session configuration
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'secret123',
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: false, // set true when HTTPS
      maxAge: 30 * 60 * 1000 // 30 minutes
    }
  })
);

// Passport init
app.use(passport.initialize());
app.use(passport.session());

// View engine
app.set('view engine', 'ejs');

// Static files (optional)
app.use(express.static('public'));

/* ================= PASSPORT CONFIG ================= */

passport.use(
  new GoogleStrategy(
    {
      clientID: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      callbackURL: process.env.GOOGLE_CALLBACK_URL
    },
    (accessToken, refreshToken, profile, done) => {
      return done(null, profile);
    }
  )
);

// Serialize / Deserialize user
passport.serializeUser((user, done) => {
  done(null, user);
});

passport.deserializeUser((user, done) => {
  done(null, user);
});

/* ================= AUTH MIDDLEWARE ================= */

function isAuthenticated(req, res, next) {
  // Prevent caching of protected pages
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');

  if (req.isAuthenticated()) {
    return next();
  }
  return res.redirect('/');
}

/* ================= ROUTES ================= */

// Login page
app.get('/', (req, res) => {
  res.render('login');
});

// Google OAuth login
app.get(
  '/auth/google',
  passport.authenticate('google', {
    scope: ['profile', 'email']
  })
);

// Google OAuth callback
app.get(
  '/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/' }),
  (req, res) => {
    res.redirect('/dashboard');
  }
);

// Protected dashboard
app.get('/dashboard', isAuthenticated, (req, res) => {
  res.render('landing', { user: req.user });
});

// Logout (POST – secure)
app.post('/logout', (req, res, next) => {
  req.logout(err => {
    if (err) return next(err);

    req.session.destroy(() => {
      res.clearCookie('connect.sid');
      res.redirect('/');
    });
  });
});

/* ================= SERVER ================= */

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

